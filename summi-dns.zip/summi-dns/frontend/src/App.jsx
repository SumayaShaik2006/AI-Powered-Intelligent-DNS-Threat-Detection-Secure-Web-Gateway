import React, { useState } from 'react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar
} from 'recharts';

/* ───────────── Mock Data ───────────── */
const timeSeriesData = [
  { time: '08:00', total: 120, blocked: 10 },
  { time: '09:00', total: 300, blocked: 45 },
  { time: '10:00', total: 450, blocked: 30 },
  { time: '11:00', total: 320, blocked: 80 },
  { time: '12:00', total: 600, blocked: 120 },
  { time: '13:00', total: 550, blocked: 60 },
  { time: '14:00', total: 400, blocked: 25 },
  { time: '15:00', total: 480, blocked: 55 },
];

const threatTypeData = [
  { name: 'DGA (AI)', value: 400, color: '#0f172a' },
  { name: 'Phishing (NLP)', value: 300, color: '#475569' },
  { name: 'Anomaly (Tunnel)', value: 150, color: '#2563eb' },
  { name: 'Malware (TI)', value: 200, color: '#dc2626' },
];

const recentLogsMock = [
  { id: 1, timestamp: "2023-10-27 10:00:05", domain: "google.com", action: "ALLOWED", reason: "Policy: Whitelist", ip: "192.168.1.10", cached: true, ms: 0.2 },
  { id: 2, timestamp: "2023-10-27 10:01:12", domain: "xjs92kdj.com", action: "BLOCKED", reason: "AI: DGA Detection", ip: "10.0.0.5", cached: false, ms: 4.1 },
  { id: 3, timestamp: "2023-10-27 10:05:44", domain: "login-update-paypal.net", action: "BLOCKED", reason: "NLP: Phishing", ip: "172.16.0.4", cached: false, ms: 3.8 },
  { id: 4, timestamp: "2023-10-27 10:12:01", domain: "github.com", action: "ALLOWED", reason: "Policy: Whitelist", ip: "192.168.1.20", cached: true, ms: 0.1 },
  { id: 5, timestamp: "2023-10-27 10:15:30", domain: "data-exfil-tunnel.com", action: "BLOCKED", reason: "Anomaly: Volume", ip: "10.0.0.8", cached: false, ms: 5.2 },
  { id: 6, timestamp: "2023-10-27 10:18:22", domain: "stackoverflow.com", action: "ALLOWED", reason: "Clean", ip: "192.168.1.15", cached: false, ms: 12.4 },
  { id: 7, timestamp: "2023-10-27 10:22:10", domain: "mining-pool-crypto.ru", action: "BLOCKED", reason: "Policy: Blacklist", ip: "10.0.0.12", cached: false, ms: 1.1 },
];

const deviceRiskMock = [
  { mac: "00:1B:44:11:3A:B7", ip: "192.168.1.10", owner: "CEO Laptop", score: 5, status: "Safe", queries: 234 },
  { mac: "00:1B:44:11:3A:C1", ip: "10.0.0.5", owner: "Guest WiFi Device", score: 85, status: "Critical", queries: 1892 },
  { mac: "00:1B:44:11:3A:A2", ip: "172.16.0.4", owner: "Marketing Workstation", score: 45, status: "Warning", queries: 567 },
  { mac: "00:1B:44:11:3A:D9", ip: "10.0.0.8", owner: "Dev Server #3", score: 95, status: "Isolated (SOAR)", queries: 4521 },
  { mac: "00:1B:44:11:3A:E4", ip: "192.168.1.15", owner: "HR Desktop", score: 12, status: "Safe", queries: 145 },
];

const soarLogsMock = [
  { time: "10:15:32", trigger: "Risk Score Critical — IP 10.0.0.8 (score: 95)", action: "NETWORK_ISOLATION", target: "00:1B:44:11:3A:D9", status: "EXECUTED" },
  { time: "10:01:15", trigger: "DGA Threshold — IP 10.0.0.5 (score: 85)", action: "ALERT_ADMIN", target: "admin@corp.local", status: "DELIVERED" },
  { time: "09:45:02", trigger: "Rate Anomaly — IP 10.0.0.8 (50+ req/10s)", action: "RATE_LIMIT", target: "10.0.0.8", status: "ENFORCED" },
];

const policiesMock = [
  { id: "p1", name: "Allow Google Services", type: "whitelist", pattern: "google.com", enabled: true, priority: 10 },
  { id: "p2", name: "Allow Microsoft Services", type: "whitelist", pattern: "microsoft.com", enabled: true, priority: 10 },
  { id: "p3", name: "Allow GitHub", type: "whitelist", pattern: "github.com", enabled: true, priority: 10 },
  { id: "p4", name: "Block Known Malware Test", type: "blacklist", pattern: "malware-test.com", enabled: true, priority: 5 },
  { id: "p5", name: "Block Gambling Sites", type: "blacklist", pattern: ".*gambling.*", enabled: true, priority: 20 },
  { id: "p6", name: "Block Crypto Mining Pools", type: "blacklist", pattern: ".*mining.*pool.*", enabled: true, priority: 15 },
];

const topBlockedMock = [
  { domain: "xjs92kdj.com", count: 142 },
  { domain: "mining-pool-crypto.ru", count: 98 },
  { domain: "login-update-paypal.net", count: 67 },
  { domain: "data-exfil-tunnel.com", count: 45 },
  { domain: "malware-test.com", count: 31 },
];

/* ───────────── SVG Icons ───────────── */
const Icons = {
  shield: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
  activity: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>,
  users: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
  zap: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>,
  lock: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>,
  list: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>,
  search: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
  logout: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>,
  database: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>,
};

/* ───────────── App ───────────── */
function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [analyzeDomain, setAnalyzeDomain] = useState('');
  const [analyzeResult, setAnalyzeResult] = useState(null);

  const handleLogin = (e) => {
    e.preventDefault();
    if (username === 'admin' && password === 'admin') {
      setIsAuthenticated(true);
    } else {
      alert("Invalid credentials. Use admin / admin");
    }
  };

  const handleAnalyze = () => {
    if (!analyzeDomain.trim()) return;
    const domain = analyzeDomain.trim().toLowerCase();
    const entropy = (() => {
      const freq = {};
      for (const c of domain) freq[c] = (freq[c] || 0) + 1;
      let e = 0;
      for (const c in freq) {
        const p = freq[c] / domain.length;
        e -= p * Math.log2(p);
      }
      return e;
    })();
    const digitRatio = (domain.match(/\d/g) || []).length / domain.length;
    const isDGA = entropy > 4.0 || (domain.length > 15 && digitRatio > 0.3);
    const brands = ['paypal','google','apple','microsoft','amazon','netflix'];
    const keywords = ['login','secure','update','verify','account'];
    const isPhishing = brands.some(b => domain.includes(b) && !domain.endsWith(`${b}.com`)) && keywords.some(k => domain.includes(k));
    
    setAnalyzeResult({
      domain,
      features: { length: domain.length, entropy: entropy.toFixed(3), digit_ratio: digitRatio.toFixed(3) },
      is_dga: isDGA,
      is_phishing: isPhishing,
      verdict: isDGA ? "MALICIOUS (DGA)" : isPhishing ? "MALICIOUS (Phishing)" : "CLEAN"
    });
  };

  /* ─── Login Screen ─── */
  if (!isAuthenticated) {
    return (
      <div style={{ display: 'flex', height: '100vh', justifyContent: 'center', alignItems: 'center', backgroundColor: 'var(--bg-color)' }}>
        <div style={{ backgroundColor: 'var(--surface-color)', padding: '3rem', borderRadius: '1rem', border: '1px solid var(--border-color)', width: '420px', boxShadow: 'var(--shadow-lg)' }}>
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1.5rem' }}>
            <div style={{ width: '48px', height: '48px', borderRadius: '12px', backgroundColor: 'var(--primary-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white' }}>
              {Icons.shield}
            </div>
          </div>
          <h2 style={{ textAlign: 'center', color: 'var(--primary-color)', marginBottom: '0.25rem', fontSize: '1.5rem' }}>SecureGateway</h2>
          <p style={{ textAlign: 'center', color: 'var(--text-muted)', marginBottom: '2rem', fontSize: '0.875rem' }}>Enterprise DNS Security Console</p>
          <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-muted)', marginBottom: '0.25rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Username</label>
              <input type="text" placeholder="admin" value={username} onChange={(e) => setUsername(e.target.value)} style={{ width: '100%' }} />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: '600', color: 'var(--text-muted)', marginBottom: '0.25rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Password</label>
              <input type="password" placeholder="••••••" value={password} onChange={(e) => setPassword(e.target.value)} style={{ width: '100%' }} />
            </div>
            <button type="submit" style={{ marginTop: '0.5rem' }}>Authenticate</button>
          </form>
        </div>
      </div>
    );
  }

  /* ─── Tab Titles ─── */
  const tabTitles = {
    dashboard: { title: 'Network Overview', desc: 'Real-time DNS traffic analysis and threat intelligence' },
    devices: { title: 'Identity & Risk', desc: 'Zero-Trust device fingerprinting and behavioral scoring' },
    soar: { title: 'Automated Response', desc: 'SOAR orchestration, auto-remediation, and webhook audit logs' },
    policies: { title: 'Security Policies', desc: 'Rule-based allow/block list management and regex pattern matching' },
    analyze: { title: 'Domain Analyzer', desc: 'Run any domain through all AI/ML detection layers in real-time' },
    doh: { title: 'DNS Configuration', desc: 'DoH endpoints, DNSSEC validation, and upstream resolver settings' },
  };

  /* ─── Render Content ─── */
  const renderContent = () => {
    switch(activeTab) {

      /* ═══ DEVICES ═══ */
      case 'devices':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', animation: 'fadeIn 0.3s' }}>
            <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
              <div className="stat-card"><div className="stat-title">Total Devices</div><div className="stat-value">{deviceRiskMock.length}</div></div>
              <div className="stat-card"><div className="stat-title">Critical Risk</div><div className="stat-value" style={{ color: 'var(--danger-color)' }}>{deviceRiskMock.filter(d => d.score >= 80).length}</div></div>
              <div className="stat-card"><div className="stat-title">Isolated by SOAR</div><div className="stat-value" style={{ color: 'var(--warning-color)' }}>{deviceRiskMock.filter(d => d.status.includes('SOAR')).length}</div></div>
            </div>
            <div className="dashboard-section">
              <div className="section-header">Zero-Trust Device Inventory</div>
              <table className="data-table">
                <thead><tr><th>Device</th><th>MAC Address</th><th>IP</th><th>Queries</th><th>Risk Score</th><th>Status</th></tr></thead>
                <tbody>
                  {deviceRiskMock.map((dev, idx) => (
                    <tr key={idx}>
                      <td style={{ fontWeight: '500' }}>{dev.owner}</td>
                      <td style={{ fontFamily: 'monospace', fontSize: '0.85rem' }}>{dev.mac}</td>
                      <td>{dev.ip}</td>
                      <td>{dev.queries.toLocaleString()}</td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                          <div style={{ width: '80px', height: '6px', backgroundColor: '#e2e8f0', borderRadius: '3px', overflow: 'hidden' }}>
                            <div style={{ width: `${dev.score}%`, height: '100%', borderRadius: '3px', backgroundColor: dev.score > 80 ? 'var(--danger-color)' : dev.score > 40 ? 'var(--warning-color)' : 'var(--success-color)', transition: 'width 0.5s ease' }}></div>
                          </div>
                          <span style={{ fontSize: '0.8rem', fontWeight: '600', minWidth: '40px' }}>{dev.score}/100</span>
                        </div>
                      </td>
                      <td><span className={`badge ${dev.score > 80 ? 'critical' : dev.score > 40 ? 'warning' : 'safe'}`}>{dev.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      /* ═══ SOAR ═══ */
      case 'soar':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', animation: 'fadeIn 0.3s' }}>
            <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
              <div className="stat-card"><div className="stat-title">Total Actions</div><div className="stat-value">{soarLogsMock.length}</div></div>
              <div className="stat-card"><div className="stat-title">Devices Isolated</div><div className="stat-value" style={{ color: 'var(--danger-color)' }}>1</div></div>
              <div className="stat-card"><div className="stat-title">Alerts Sent</div><div className="stat-value" style={{ color: 'var(--accent-color)' }}>2</div></div>
            </div>
            <div className="dashboard-section">
              <div className="section-header">SOAR Auto-Remediation Audit Trail</div>
              <table className="data-table">
                <thead><tr><th>Timestamp</th><th>Detection Trigger</th><th>Automated Action</th><th>Target</th><th>Result</th></tr></thead>
                <tbody>
                  {soarLogsMock.map((log, idx) => (
                    <tr key={idx}>
                      <td style={{ color: 'var(--text-muted)' }}>{log.time}</td>
                      <td style={{ fontWeight: '500' }}>{log.trigger}</td>
                      <td><span className="badge action">{log.action}</span></td>
                      <td style={{ fontFamily: 'monospace', fontSize: '0.85rem' }}>{log.target}</td>
                      <td><span className="badge safe">{log.status}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      /* ═══ POLICIES ═══ */
      case 'policies':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', animation: 'fadeIn 0.3s' }}>
            <div className="dashboard-section">
              <div className="section-header">Active Security Policies</div>
              <table className="data-table">
                <thead><tr><th>Priority</th><th>Policy Name</th><th>Type</th><th>Pattern</th><th>Status</th></tr></thead>
                <tbody>
                  {policiesMock.map((p) => (
                    <tr key={p.id}>
                      <td style={{ fontWeight: '600' }}>{p.priority}</td>
                      <td style={{ fontWeight: '500' }}>{p.name}</td>
                      <td><span className={`badge ${p.type === 'whitelist' ? 'safe' : 'critical'}`}>{p.type.toUpperCase()}</span></td>
                      <td style={{ fontFamily: 'monospace', fontSize: '0.85rem' }}>{p.pattern}</td>
                      <td><span className={`badge ${p.enabled ? 'safe' : 'warning'}`}>{p.enabled ? 'ENABLED' : 'DISABLED'}</span></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      /* ═══ ANALYZE ═══ */
      case 'analyze':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', animation: 'fadeIn 0.3s' }}>
            <div className="dashboard-section">
              <div className="section-header">Real-Time Domain Threat Analysis</div>
              <p style={{ color: 'var(--text-muted)', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
                Enter any domain to analyze it through the DGA Machine Learning model, NLP Phishing detector, and Policy Engine simultaneously.
              </p>
              <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.5rem' }}>
                <input 
                  type="text" 
                  placeholder="e.g. secure-paypal-login-update.com" 
                  value={analyzeDomain} 
                  onChange={(e) => setAnalyzeDomain(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAnalyze()}
                  style={{ flex: 1 }}
                />
                <button onClick={handleAnalyze}>Analyze</button>
              </div>
              {analyzeResult && (
                <div style={{ padding: '1.5rem', backgroundColor: '#f8fafc', borderRadius: '0.75rem', border: `2px solid ${analyzeResult.is_dga || analyzeResult.is_phishing ? 'var(--danger-color)' : 'var(--success-color)'}` }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                    <h3 style={{ fontFamily: 'monospace', fontSize: '1.1rem' }}>{analyzeResult.domain}</h3>
                    <span className={`badge ${analyzeResult.is_dga || analyzeResult.is_phishing ? 'critical' : 'safe'}`} style={{ fontSize: '0.8rem', padding: '0.4rem 0.8rem' }}>
                      {analyzeResult.verdict}
                    </span>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem' }}>
                    <div style={{ padding: '1rem', backgroundColor: 'white', borderRadius: '0.5rem', border: '1px solid var(--border-color)' }}>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: '600', textTransform: 'uppercase', marginBottom: '0.25rem' }}>Shannon Entropy</div>
                      <div style={{ fontSize: '1.5rem', fontWeight: '700' }}>{analyzeResult.features.entropy}</div>
                    </div>
                    <div style={{ padding: '1rem', backgroundColor: 'white', borderRadius: '0.5rem', border: '1px solid var(--border-color)' }}>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: '600', textTransform: 'uppercase', marginBottom: '0.25rem' }}>Length</div>
                      <div style={{ fontSize: '1.5rem', fontWeight: '700' }}>{analyzeResult.features.length}</div>
                    </div>
                    <div style={{ padding: '1rem', backgroundColor: 'white', borderRadius: '0.5rem', border: '1px solid var(--border-color)' }}>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontWeight: '600', textTransform: 'uppercase', marginBottom: '0.25rem' }}>Digit Ratio</div>
                      <div style={{ fontSize: '1.5rem', fontWeight: '700' }}>{analyzeResult.features.digit_ratio}</div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
                    <div style={{ flex: 1, padding: '0.75rem', backgroundColor: 'white', borderRadius: '0.5rem', border: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: '0.85rem', fontWeight: '500' }}>DGA Model</span>
                      <span className={`badge ${analyzeResult.is_dga ? 'critical' : 'safe'}`}>{analyzeResult.is_dga ? 'DETECTED' : 'CLEAN'}</span>
                    </div>
                    <div style={{ flex: 1, padding: '0.75rem', backgroundColor: 'white', borderRadius: '0.5rem', border: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span style={{ fontSize: '0.85rem', fontWeight: '500' }}>Phishing NLP</span>
                      <span className={`badge ${analyzeResult.is_phishing ? 'critical' : 'safe'}`}>{analyzeResult.is_phishing ? 'DETECTED' : 'CLEAN'}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      /* ═══ DoH / DNSSEC ═══ */
      case 'doh':
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', animation: 'fadeIn 0.3s' }}>
            <div className="dashboard-section">
              <div className="section-header">DNSSEC Cryptographic Validation</div>
              <div style={{ padding: '1.25rem', backgroundColor: '#f0fdf4', borderRadius: '0.5rem', border: '1px solid #bbf7d0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <strong>Enforce RRSIG Chain-of-Trust</strong>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Drops upstream responses with missing or invalid DNSSEC signatures. Protects against DNS Cache Poisoning (Kaminsky Attack).</div>
                </div>
                <span className="badge safe" style={{ padding: '0.4rem 0.8rem' }}>STRICT MODE</span>
              </div>
            </div>
            <div className="dashboard-section">
              <div className="section-header">DoH Endpoint (RFC 8484)</div>
              <div style={{ padding: '1.25rem', backgroundColor: '#f8fafc', borderRadius: '0.5rem', border: '1px solid var(--border-color)' }}>
                <div style={{ fontFamily: 'monospace', fontSize: '0.9rem', color: 'var(--accent-color)', marginBottom: '0.5rem' }}>POST /dns-query</div>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>Accepts <code>application/dns-message</code> content type. Base64url-encoded wireformat DNS in GET requests.</div>
              </div>
            </div>
            <div className="dashboard-section">
              <div className="section-header">Upstream Resolver Chain</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem' }}>
                <div style={{ padding: '1.25rem', backgroundColor: '#ffffff', borderRadius: '0.5rem', border: '2px solid var(--primary-color)' }}>
                  <strong>Cloudflare</strong><div style={{ fontFamily: 'monospace', fontSize: '0.85rem', color: 'var(--text-muted)' }}>1.1.1.1 (Primary)</div>
                </div>
                <div style={{ padding: '1.25rem', backgroundColor: '#ffffff', borderRadius: '0.5rem', border: '1px solid var(--border-color)' }}>
                  <strong>Quad9</strong><div style={{ fontFamily: 'monospace', fontSize: '0.85rem', color: 'var(--text-muted)' }}>9.9.9.9 (Secondary)</div>
                </div>
                <div style={{ padding: '1.25rem', backgroundColor: '#ffffff', borderRadius: '0.5rem', border: '1px solid var(--border-color)' }}>
                  <strong>Google DNS</strong><div style={{ fontFamily: 'monospace', fontSize: '0.85rem', color: 'var(--text-muted)' }}>8.8.8.8 (Fallback)</div>
                </div>
              </div>
            </div>
            <div className="dashboard-section">
              <div className="section-header">Cache Performance</div>
              <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)' }}>
                <div className="stat-card"><div className="stat-title">Cached Entries</div><div className="stat-value">1,247</div></div>
                <div className="stat-card"><div className="stat-title">Hit Rate</div><div className="stat-value" style={{ color: 'var(--success-color)' }}>78.4%</div></div>
                <div className="stat-card"><div className="stat-title">Avg Latency (Cache)</div><div className="stat-value">0.2ms</div></div>
                <div className="stat-card"><div className="stat-title">Avg Latency (Upstream)</div><div className="stat-value">12.4ms</div></div>
              </div>
            </div>
          </div>
        );

      /* ═══ DASHBOARD (DEFAULT) ═══ */
      default:
        return (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem', animation: 'fadeIn 0.3s' }}>
            {/* Stats Grid */}
            <div className="stats-grid">
              <div className="stat-card">
                <div className="stat-title">Total Queries (24h)</div>
                <div className="stat-value">15,423</div>
              </div>
              <div className="stat-card">
                <div className="stat-title">DoH Encrypted</div>
                <div className="stat-value" style={{ color: 'var(--accent-color)' }}>4,892</div>
              </div>
              <div className="stat-card">
                <div className="stat-title">Threats Neutralized</div>
                <div className="stat-value" style={{ color: 'var(--danger-color)' }}>342</div>
              </div>
              <div className="stat-card">
                <div className="stat-title">Cache Hit Rate</div>
                <div className="stat-value" style={{ color: 'var(--success-color)' }}>78.4%</div>
              </div>
            </div>

            {/* Charts */}
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem' }}>
              <div className="dashboard-section">
                <div className="section-header">Traffic & Threat Timeline</div>
                <div style={{ height: '300px' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={timeSeriesData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="gradTotal" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#0f172a" stopOpacity={0.08}/>
                          <stop offset="95%" stopColor="#0f172a" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="gradBlocked" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#dc2626" stopOpacity={0.08}/>
                          <stop offset="95%" stopColor="#dc2626" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="time" stroke="#94a3b8" tick={{ fontSize: 12 }} />
                      <YAxis stroke="#94a3b8" tick={{ fontSize: 12 }} />
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '0.5rem', fontSize: '0.85rem', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }} />
                      <Area type="monotone" dataKey="total" stroke="#0f172a" strokeWidth={2} fillOpacity={1} fill="url(#gradTotal)" name="Total" />
                      <Area type="monotone" dataKey="blocked" stroke="#dc2626" strokeWidth={2} fillOpacity={1} fill="url(#gradBlocked)" name="Blocked" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="dashboard-section">
                <div className="section-header">Detection Sources</div>
                <div style={{ height: '200px' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie data={threatTypeData} cx="50%" cy="50%" innerRadius={55} outerRadius={75} paddingAngle={3} dataKey="value">
                        {threatTypeData.map((entry, index) => (<Cell key={`cell-${index}`} fill={entry.color} />))}
                      </Pie>
                      <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '0.5rem', fontSize: '0.85rem' }} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', marginTop: '0.5rem' }}>
                  {threatTypeData.map((t, i) => (
                    <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <div style={{ width: '10px', height: '10px', borderRadius: '2px', backgroundColor: t.color }}></div>
                        <span style={{ fontSize: '0.85rem', fontWeight: '500' }}>{t.name}</span>
                      </div>
                      <span style={{ fontWeight: '600', fontSize: '0.85rem' }}>{t.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Top Blocked + Logs side by side */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '2rem' }}>
              <div className="dashboard-section">
                <div className="section-header">Top Blocked Domains</div>
                <div style={{ height: '250px' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={topBlockedMock} layout="vertical" margin={{ left: 10 }}>
                      <XAxis type="number" stroke="#94a3b8" tick={{ fontSize: 11 }} />
                      <YAxis type="category" dataKey="domain" width={160} stroke="#94a3b8" tick={{ fontSize: 11 }} />
                      <Tooltip contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '0.5rem', fontSize: '0.85rem' }} />
                      <Bar dataKey="count" fill="#0f172a" radius={[0, 4, 4, 0]} barSize={16} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="dashboard-section">
                <div className="section-header">Real-Time DNS Audit Log</div>
                <table className="data-table">
                  <thead><tr><th>Time</th><th>IP</th><th>Domain</th><th>Action</th><th>Reason</th><th>Latency</th></tr></thead>
                  <tbody>
                    {recentLogsMock.map((log) => (
                      <tr key={log.id}>
                        <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>{log.timestamp.split(' ')[1]}</td>
                        <td style={{ fontWeight: '500', fontSize: '0.85rem' }}>{log.ip}</td>
                        <td style={{ fontFamily: 'monospace', fontSize: '0.82rem' }}>{log.domain}</td>
                        <td><span className={`badge ${log.action.toLowerCase()}`}>{log.action}</span></td>
                        <td style={{ fontSize: '0.85rem' }}>{log.reason}</td>
                        <td style={{ fontSize: '0.85rem', color: log.cached ? 'var(--success-color)' : 'var(--text-muted)' }}>{log.ms}ms {log.cached ? '⚡' : ''}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );
    }
  };

  const currentTab = tabTitles[activeTab] || tabTitles.dashboard;

  return (
    <div className="app-container">
      {/* ─── Sidebar ─── */}
      <aside className="sidebar">
        <div className="sidebar-title">
          <div style={{ width: '32px', height: '32px', borderRadius: '8px', backgroundColor: 'var(--primary-color)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white' }}>
            {Icons.shield}
          </div>
          SecureGateway
        </div>
        
        <div className="sidebar-nav">
          <div style={{ fontSize: '0.7rem', fontWeight: '600', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '0.5rem 1rem 0.25rem', marginTop: '0.5rem' }}>Monitoring</div>
          <div className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`} onClick={() => setActiveTab('dashboard')}>{Icons.activity} Overview</div>
          <div className={`nav-item ${activeTab === 'devices' ? 'active' : ''}`} onClick={() => setActiveTab('devices')}>{Icons.users} Device Risk</div>
          
          <div style={{ fontSize: '0.7rem', fontWeight: '600', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '0.5rem 1rem 0.25rem', marginTop: '0.5rem' }}>Security</div>
          <div className={`nav-item ${activeTab === 'soar' ? 'active' : ''}`} onClick={() => setActiveTab('soar')}>{Icons.zap} SOAR</div>
          <div className={`nav-item ${activeTab === 'policies' ? 'active' : ''}`} onClick={() => setActiveTab('policies')}>{Icons.list} Policies</div>
          <div className={`nav-item ${activeTab === 'analyze' ? 'active' : ''}`} onClick={() => setActiveTab('analyze')}>{Icons.search} Analyzer</div>

          <div style={{ fontSize: '0.7rem', fontWeight: '600', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', padding: '0.5rem 1rem 0.25rem', marginTop: '0.5rem' }}>System</div>
          <div className={`nav-item ${activeTab === 'doh' ? 'active' : ''}`} onClick={() => setActiveTab('doh')}>{Icons.database} DNS & Cache</div>
          
          <div className="nav-item" onClick={() => setIsAuthenticated(false)} style={{ color: 'var(--danger-color)', marginTop: 'auto' }}>
            {Icons.logout} Sign Out
          </div>
        </div>
      </aside>

      {/* ─── Main Content ─── */}
      <main className="main-content">
        <header className="header">
          <div>
            <h1 className="header-title">{currentTab.title}</h1>
            <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>{currentTab.desc}</p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.5rem', backgroundColor: 'var(--surface-color)', padding: '0.5rem 1rem', borderRadius: '2rem', border: '1px solid var(--border-color)', boxShadow: 'var(--shadow-sm)' }}>
              <span className="live-indicator"></span> Operational
            </span>
          </div>
        </header>
        {renderContent()}
      </main>
    </div>
  );
}

export default App;
