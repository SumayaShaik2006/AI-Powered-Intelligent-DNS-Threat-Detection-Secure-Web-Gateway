# AI-Powered Intelligent DNS Threat Detection & Secure Web Gateway

> **Enterprise-Grade Security Platform** — A multi-layered DNS filtering gateway powered by Machine Learning, NLP Phishing Detection, Zero-Trust Device Fingerprinting, and automated SOAR remediation.

---

## Architecture Overview

```
┌───────────────────────────────────────────────────────────┐
│                   React Dashboard (Vite)                  │
│  Login │ Overview │ Device Risk │ SOAR │ Policies │ DoH   │
└──────────────────────┬────────────────────────────────────┘
                       │ REST API (CORS)
┌──────────────────────┴────────────────────────────────────┐
│                 FastAPI Backend (Python)                   │
│  ┌──────────┐  ┌────────────┐  ┌──────────────────────┐  │
│  │ DNS Proxy│  │ ML Engine  │  │ Security Modules     │  │
│  │ (UDP)    │  │ DGA + NLP  │  │ SOAR / Zero-Trust /  │  │
│  │ + DoH    │  │ + Features │  │ Policy / Anomaly     │  │
│  └──────────┘  └────────────┘  └──────────────────────┘  │
│  ┌──────────┐  ┌────────────┐  ┌──────────────────────┐  │
│  │DNS Cache │  │Query Logger│  │ TI Aggregator        │  │
│  │ (TTL)    │  │ (In-Memory)│  │ (Abuse.ch/PhishTank) │  │
│  └──────────┘  └────────────┘  └──────────────────────┘  │
└───────────────────────────────────────────────────────────┘
```

## Features

### Core Engine
- **Asynchronous DNS Proxy** — High-performance UDP listener using Python `asyncio`
- **DNS over HTTPS (DoH)** — RFC 8484 compliant encrypted DNS endpoint
- **DNSSEC Validation** — Cryptographic signature verification to prevent cache poisoning
- **Intelligent DNS Cache** — TTL-based response caching with hit/miss statistics

### AI/ML Detection Layers
- **DGA Detection (Random Forest)** — Machine learning model trained to detect domain generation algorithms using Shannon entropy, domain length, and digit ratio features
- **NLP Phishing Detection** — Heuristic-based typosquatting detector for brand impersonation (PayPal, Google, Microsoft, etc.)
- **Anomaly Detection** — Time-series rate analysis to detect DNS tunneling and volumetric attacks

### Enterprise Security
- **Zero-Trust Device Fingerprinting** — Tracks individual device behavior and assigns dynamic risk scores (0-100)
- **SOAR Auto-Remediation** — Automated webhook-driven response system that isolates compromised devices
- **Policy Engine** — Rule-based whitelist/blacklist with regex pattern matching and priority ordering
- **Threat Intelligence Aggregation** — Integrates OSINT feeds (Abuse.ch, PhishTank)

### Dashboard
- **JWT Authentication** — Secured admin access
- **6 Interactive Panels** — Overview, Device Risk, SOAR Logs, Security Policies, Domain Analyzer, DNS Configuration
- **Real-Time Charts** — Traffic timeline, threat breakdown pie chart, top blocked domains bar chart
- **Domain Analyzer Tool** — Live domain threat analysis through all AI/ML layers simultaneously

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite + Recharts |
| Backend | Python 3.10+ + FastAPI + Uvicorn |
| ML | scikit-learn + Random Forest Classifier |
| DNS | dnslib (UDP proxy + DoH) |
| Styling | Custom CSS (Enterprise Light Theme) |

## Project Structure

```
summi-dns/
├── backend/
│   ├── core/
│   │   ├── anomaly_detector.py   # DNS tunneling / rate anomaly detection
│   │   ├── config.py             # Environment configuration
│   │   ├── device_tracker.py     # Zero-Trust device risk scoring
│   │   ├── dns_cache.py          # TTL-based DNS response cache
│   │   ├── dns_proxy.py          # Core async DNS proxy (UDP)
│   │   ├── policy_engine.py      # Rule-based allow/block policies
│   │   ├── query_logger.py       # Structured query event logging
│   │   ├── soar_remediation.py   # SOAR auto-isolation webhooks
│   │   └── ti_aggregator.py      # Threat intelligence feed aggregator
│   ├── ml/
│   │   └── engine.py             # ML feature extraction + DGA/Phishing prediction
│   ├── model_training/
│   │   └── train.py              # Random Forest model training script
│   ├── main.py                   # FastAPI application + REST API endpoints
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── App.jsx               # React dashboard (6 tabs)
│   │   ├── index.css             # Enterprise minimal theme
│   │   └── main.jsx              # React entry point
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── docker-compose.yml
└── README.md
```

## Quick Start

### 1. Backend
```bash
cd backend
pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
```

### 3. Open Dashboard
Navigate to `http://localhost:5173` and login with:
- **Username:** `admin`
- **Password:** `admin`

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check |
| GET | `/api/stats` | Basic statistics |
| GET | `/api/logs` | Recent DNS logs |
| GET | `/api/query-log` | Detailed query event log |
| GET | `/api/live-stats` | Aggregate live statistics |
| GET | `/api/cache-stats` | DNS cache performance |
| GET | `/api/devices` | Zero-Trust device inventory |
| GET | `/api/soar-logs` | SOAR remediation audit trail |
| GET | `/api/policies` | List security policies |
| POST | `/api/policies` | Create new policy |
| DELETE | `/api/policies/:id` | Delete a policy |
| POST | `/api/analyze` | Analyze domain through all AI layers |
| POST | `/api/login` | JWT authentication |
| GET/POST | `/dns-query` | DNS over HTTPS (RFC 8484) |

## License

This project is developed as a final-year academic project for educational purposes.
