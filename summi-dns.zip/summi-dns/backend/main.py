import asyncio
from fastapi import FastAPI, BackgroundTasks, Request, Response, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import base64
from dnslib import DNSRecord, QTYPE, RR, A
from .core.dns_proxy import start_dns_server, dga_detector
from .core.query_logger import query_logger
from .core.policy_engine import policy_engine
from .core.dns_cache import dns_cache
from .core.device_tracker import tracker
from .core.soar_remediation import soar_engine

app = FastAPI(title="DNS Filter API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    # Start the DNS server in the background alongside FastAPI
    asyncio.create_task(start_dns_server())
    print("Background DNS Proxy started.")

@app.get("/api/health")
def health_check():
    return {"status": "ok"}

@app.get("/api/stats")
def get_stats():
    # Mock statistics
    return {
        "total_queries": 15423,
        "blocked_queries": 321,
        "dga_detected": 45,
        "active_policies": 12
    }

@app.get("/api/logs")
def get_recent_logs():
    return [
        {"timestamp": "2023-10-27T10:00:00Z", "domain": "google.com", "action": "ALLOWED", "reason": "Whitelist"},
        {"timestamp": "2023-10-27T10:05:00Z", "domain": "malicious-dga-xj392k.com", "action": "BLOCKED", "reason": "AI DGA Detection"},
        {"timestamp": "2023-10-27T10:10:00Z", "domain": "phishing.net", "action": "BLOCKED", "reason": "Threat Intel Match"}
    ]

# --- Advanced Features ---

@app.post("/api/login")
def login(creds: dict):
    if creds.get("username") == "admin" and creds.get("password") == "admin":
        return {"token": "mock_jwt_token_12345"}
    raise HTTPException(status_code=401, detail="Invalid credentials")

@app.get("/api/geoip")
def get_geoip_threats():
    # Returns mock coordinates of blocked threats for the global map
    return [
        {"lat": 55.7558, "lng": 37.6173, "name": "Moscow - C2 Server"},
        {"lat": 39.9042, "lng": 116.4074, "name": "Beijing - Malware Drop"},
        {"lat": 38.9072, "lng": -77.0369, "name": "Washington - Anomaly"}
    ]

@app.get("/dns-query")
@app.post("/dns-query")
async def dns_over_https(request: Request):
    """
    DNS over HTTPS (DoH) Implementation (RFC 8484)
    """
    data = None
    if request.method == "POST":
        if request.headers.get("content-type") != "application/dns-message":
            raise HTTPException(status_code=415, detail="Unsupported media type")
        data = await request.body()
    elif request.method == "GET":
        dns_param = request.query_params.get("dns")
        if not dns_param:
            raise HTTPException(status_code=400, detail="Missing dns query parameter")
        # Base64Url decoding
        padded = dns_param + "=" * ((4 - len(dns_param) % 4) % 4)
        data = base64.urlsafe_b64decode(padded)
        
    if not data:
        raise HTTPException(status_code=400, detail="Invalid request")

    try:
        dns_req = DNSRecord.parse(data)
        # Process the request using the same logic as the UDP proxy
        # For simplicity in this demo, we mock the resolution
        qname = str(dns_req.q.qname)
        is_malicious = dga_detector.predict(qname)
        
        reply = dns_req.reply()
        if is_malicious:
            reply.add_answer(RR(dns_req.q.qname, QTYPE.A, rdata=A("0.0.0.0"), ttl=60))
        else:
             reply.add_answer(RR(dns_req.q.qname, QTYPE.A, rdata=A("1.1.1.1"), ttl=60)) # Mock upstream
             
        return Response(content=reply.pack(), media_type="application/dns-message")
    except Exception as e:
         raise HTTPException(status_code=500, detail=str(e))

# --- Live Data Endpoints ---

@app.get("/api/query-log")
def get_query_log():
    """Returns the most recent 50 DNS query events."""
    return query_logger.get_recent(50)

@app.get("/api/live-stats")
def get_live_stats():
    """Returns aggregate query statistics (totals, avg response time, top blocked)."""
    return query_logger.get_stats()

@app.get("/api/cache-stats")
def get_cache_stats():
    """Returns DNS cache performance (hit rate, miss rate, entries)."""
    return dns_cache.cache_stats()

@app.get("/api/devices")
def get_devices():
    """Returns all tracked devices and their Zero-Trust risk scores."""
    return list(tracker.devices.values())

@app.get("/api/soar-logs")
def get_soar_logs():
    """Returns all SOAR auto-remediation action logs."""
    return soar_engine.action_logs

# --- Policy Engine CRUD ---

@app.get("/api/policies")
def get_policies():
    """Returns all security policies sorted by priority."""
    return policy_engine.list_policies()

@app.post("/api/policies")
def add_policy(policy: dict):
    """Create a new allow/block policy rule."""
    return policy_engine.add_policy(
        name=policy["name"],
        policy_type=policy["type"],
        pattern=policy["pattern"],
        priority=policy.get("priority", 50)
    )

@app.delete("/api/policies/{policy_id}")
def delete_policy(policy_id: str):
    """Delete a policy by ID."""
    success = policy_engine.remove_policy(policy_id)
    if not success:
        raise HTTPException(status_code=404, detail="Policy not found")
    return {"status": "deleted"}

@app.post("/api/policies/{policy_id}/toggle")
def toggle_policy(policy_id: str):
    """Enable/disable a policy."""
    result = policy_engine.toggle_policy(policy_id)
    if result is None:
        raise HTTPException(status_code=404, detail="Policy not found")
    return result

# --- Domain Analysis Tool ---

@app.post("/api/analyze")
def analyze_domain(body: dict):
    """Analyze a domain through all security layers (DGA, NLP, Policy)."""
    domain = body.get("domain", "")
    if not domain:
        raise HTTPException(status_code=400, detail="Missing domain")
    features = dga_detector.extract_features(domain)
    is_dga = dga_detector.predict(domain)
    is_phishing = dga_detector.detect_phishing(domain)
    policy_result = policy_engine.evaluate(domain)
    return {
        "domain": domain,
        "features": features,
        "is_dga": is_dga,
        "is_phishing": is_phishing,
        "policy": policy_result
    }
