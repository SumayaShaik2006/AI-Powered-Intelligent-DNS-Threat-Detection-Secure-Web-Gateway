import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import joblib
import math
from collections import Counter
import os

def shannon_entropy(domain: str) -> float:
    p, lns = Counter(domain), float(len(domain))
    return -sum(count/lns * math.log(count/lns, 2) for count in p.values())

def extract_features(domain: str):
    return [
        len(domain),
        shannon_entropy(domain),
        sum(1 for c in domain if c in 'aeiou') / len(domain) if len(domain) > 0 else 0,
        sum(1 for c in domain if c.isdigit()) / len(domain) if len(domain) > 0 else 0
    ]

def generate_mock_data(n=1000):
    """Generates some mock data to demonstrate the training pipeline."""
    data = []
    # Benign examples
    for _ in range(n // 2):
        data.append({
            'domain': 'example.com', # Simplification for mock
            'is_dga': 0,
            'length': np.random.normal(10, 2),
            'entropy': np.random.normal(3.0, 0.5),
            'vowel_ratio': np.random.uniform(0.2, 0.4),
            'digit_ratio': np.random.uniform(0.0, 0.1)
        })
    # DGA examples
    for _ in range(n // 2):
        data.append({
            'domain': 'xjksdhfkjhasd.com', 
            'is_dga': 1,
            'length': np.random.normal(20, 5),
            'entropy': np.random.normal(4.5, 0.5),
            'vowel_ratio': np.random.uniform(0.0, 0.15),
            'digit_ratio': np.random.uniform(0.2, 0.5)
        })
    return pd.DataFrame(data)

if __name__ == "__main__":
    print("Generating mock dataset...")
    df = generate_mock_data(2000)
    
    X = df[['length', 'entropy', 'vowel_ratio', 'digit_ratio']]
    y = df['is_dga']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    print("Training Random Forest Classifier...")
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    print("Evaluating model...")
    y_pred = model.predict(X_test)
    print(f"Accuracy: {accuracy_score(y_test, y_pred):.4f}")
    print(classification_report(y_test, y_pred))
    
    os.makedirs('../ml', exist_ok=True)
    model_path = '../ml/dga_model.pkl'
    joblib.dump(model, model_path)
    print(f"Model saved to {model_path}")
