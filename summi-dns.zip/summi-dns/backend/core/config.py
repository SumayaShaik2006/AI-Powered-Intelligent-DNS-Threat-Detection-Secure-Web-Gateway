import os

# DNS Settings
UPSTREAM_DNS = os.getenv("UPSTREAM_DNS", "1.1.1.1")
DNS_PORT = int(os.getenv("DNS_PORT", 5053))  # Using 5053 for testing without root
DNS_HOST = os.getenv("DNS_HOST", "0.0.0.0")

# API Settings
API_PORT = int(os.getenv("API_PORT", 8000))
API_HOST = os.getenv("API_HOST", "0.0.0.0")

# Redis Settings
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
