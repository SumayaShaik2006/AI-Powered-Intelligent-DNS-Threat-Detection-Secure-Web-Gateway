import requests
import logging
import asyncio

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("TIAggregator")

# Example feeds
FEEDS = [
    "https://urlhaus.abuse.ch/downloads/text_online/",
    # Can add more feeds like PhishTank, openphish, etc.
]

async def fetch_threat_intel():
    """
    Periodically fetches threat intelligence feeds and updates the local cache/database.
    For this project, we'll simulate fetching and maintaining an in-memory blocklist.
    """
    logger.info("Starting Threat Intelligence Aggregator...")
    
    blocked_domains = set()
    
    for feed_url in FEEDS:
        try:
            logger.info(f"Fetching TI feed from: {feed_url}")
            # Mocking the request to avoid blocking during demo, in a real scenario use httpx
            # response = requests.get(feed_url, timeout=10)
            
            # Simulated data processing
            logger.info("Processing Threat Intel feed data...")
            # For demonstration, we'll manually add some known malicious domains
            blocked_domains.update([
                "malicious.com",
                "phishing-login.net",
                "evil-malware-drop.org",
                "c2-server.ru"
            ])
            logger.info(f"Successfully processed {len(blocked_domains)} malicious domains from feeds.")
        except Exception as e:
            logger.error(f"Failed to fetch TI feed from {feed_url}: {e}")

    return blocked_domains

async def periodic_ti_update(interval_seconds=3600):
    """Background task to run the TI fetcher periodically."""
    while True:
        await fetch_threat_intel()
        logger.info(f"TI Aggregator sleeping for {interval_seconds} seconds.")
        await asyncio.sleep(interval_seconds)

if __name__ == "__main__":
    asyncio.run(fetch_threat_intel())
