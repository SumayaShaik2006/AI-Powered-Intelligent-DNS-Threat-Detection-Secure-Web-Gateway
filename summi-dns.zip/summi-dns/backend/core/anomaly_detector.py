import time
import logging

logger = logging.getLogger("AnomalyDetector")

class AnomalyDetector:
    def __init__(self, time_window=10, max_requests=50):
        # Maps IP to list of timestamps
        self.request_logs = {}
        self.time_window = time_window
        self.max_requests = max_requests

    def is_anomalous(self, ip_address: str, domain: str) -> bool:
        """
        Checks for DNS tunneling or DoS patterns by analyzing query rates per IP.
        """
        current_time = time.time()
        
        if ip_address not in self.request_logs:
            self.request_logs[ip_address] = []
            
        # Add current request
        self.request_logs[ip_address].append(current_time)
        
        # Clean up old requests outside the time window
        self.request_logs[ip_address] = [
            t for t in self.request_logs[ip_address] 
            if current_time - t <= self.time_window
        ]
        
        # Check volume anomaly
        if len(self.request_logs[ip_address]) > self.max_requests:
            logger.warning(f"Anomaly Detected! High volume from IP {ip_address}. Potential DNS Tunneling or DoS.")
            return True
            
        return False

# Singleton instance
rate_limiter = AnomalyDetector()
