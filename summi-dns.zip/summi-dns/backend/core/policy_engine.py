import re
import uuid
import logging

logger = logging.getLogger("PolicyEngine")

class PolicyEngine:
    """
    Rule-based security policy engine for custom allow/block rules.
    Supports exact domain matching and regex patterns.
    Policies are evaluated in priority order (lower number = higher priority).
    """
    def __init__(self):
        self._policies = []
        self._load_defaults()

    def _load_defaults(self):
        """Load default enterprise security policies."""
        defaults = [
            {"name": "Allow Google Services", "type": "whitelist", "pattern": "google.com", "priority": 10},
            {"name": "Allow Microsoft Services", "type": "whitelist", "pattern": "microsoft.com", "priority": 10},
            {"name": "Allow GitHub", "type": "whitelist", "pattern": "github.com", "priority": 10},
            {"name": "Block Known Malware Test", "type": "blacklist", "pattern": "malware-test.com", "priority": 5},
            {"name": "Block Gambling Sites", "type": "blacklist", "pattern": r".*gambling.*", "priority": 20},
            {"name": "Block Crypto Mining Pools", "type": "blacklist", "pattern": r".*mining.*pool.*", "priority": 15},
        ]
        for d in defaults:
            self.add_policy(d["name"], d["type"], d["pattern"], d["priority"])

    def add_policy(self, name: str, policy_type: str, pattern: str, priority: int = 50) -> dict:
        """Add a new security policy rule."""
        policy = {
            "id": str(uuid.uuid4())[:8],
            "name": name,
            "type": policy_type,  # "whitelist" or "blacklist"
            "pattern": pattern,
            "enabled": True,
            "priority": priority
        }
        self._policies.append(policy)
        self._policies.sort(key=lambda p: p["priority"])
        logger.info(f"Policy added: {name} ({policy_type}: {pattern})")
        return policy

    def remove_policy(self, policy_id: str) -> bool:
        """Remove a policy by its ID."""
        for i, p in enumerate(self._policies):
            if p["id"] == policy_id:
                removed = self._policies.pop(i)
                logger.info(f"Policy removed: {removed['name']}")
                return True
        return False

    def toggle_policy(self, policy_id: str) -> dict:
        """Enable or disable a policy."""
        for p in self._policies:
            if p["id"] == policy_id:
                p["enabled"] = not p["enabled"]
                state = "enabled" if p["enabled"] else "disabled"
                logger.info(f"Policy {p['name']} {state}")
                return p
        return None

    def list_policies(self) -> list:
        """Return all policies sorted by priority."""
        return self._policies

    def evaluate(self, domain: str) -> dict:
        """
        Evaluate a domain against all enabled policies in priority order.
        Returns the first matching policy's action.
        """
        domain_lower = domain.lower().rstrip('.')
        
        for policy in self._policies:
            if not policy["enabled"]:
                continue

            matched = False
            pattern = policy["pattern"].lower()

            # Try regex match first, then exact/substring match
            try:
                if re.fullmatch(pattern, domain_lower):
                    matched = True
            except re.error:
                pass

            if not matched and (pattern in domain_lower or domain_lower.endswith(pattern)):
                matched = True

            if matched:
                action = "ALLOW" if policy["type"] == "whitelist" else "BLOCK"
                return {"action": action, "policy_name": policy["name"], "policy_id": policy["id"]}

        return {"action": "NONE", "policy_name": None, "policy_id": None}

# Singleton
policy_engine = PolicyEngine()
