import asyncio
import logging
from dnslib import DNSRecord, QTYPE, RR, A, DNSHeader
from .config import UPSTREAM_DNS, DNS_PORT, DNS_HOST
from ..ml.engine import dga_detector
from .anomaly_detector import rate_limiter
from .device_tracker import tracker
from .soar_remediation import soar_engine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("DNSProxy")

class DNSProxyProtocol(asyncio.DatagramProtocol):
    def __init__(self):
        self.transport = None

    def connection_made(self, transport):
        self.transport = transport
        logger.info(f"DNS Proxy listening on {DNS_HOST}:{DNS_PORT}")

    def datagram_received(self, data, addr):
        asyncio.create_task(self.handle_query(data, addr))

    async def handle_query(self, data, addr):
        try:
            request = DNSRecord.parse(data)
            qname = str(request.q.qname).rstrip('.')
            qtype = QTYPE[request.q.qtype]

            logger.info(f"Received query from {addr}: {qtype} {qname}")
            
            client_ip = addr[0]

            # 0. Check Anomaly Detection (DNS Tunneling / DoS)
            if rate_limiter.is_anomalous(client_ip, qname):
                logger.warning(f"BLOCKED: {client_ip} due to rate anomaly")
                self.handle_threat(client_ip, qname, request, addr, "Rate Anomaly", 25)
                return

            # 1. Check Threat Intel (Redis) -> To be implemented
            is_malicious = await self.check_threat_intel(qname)
            
            # 2. Check ML Engine -> To be implemented
            if not is_malicious:
                 is_malicious = await self.check_ml_engine(qname)

            if is_malicious:
                logger.warning(f"BLOCKED: {qname}")
                self.handle_threat(client_ip, qname, request, addr, "Malicious Domain", 15)
                return

            # 3. Forward to Upstream & DNSSEC Validation
            response_data = await self.forward_to_upstream(data)
            if response_data:
                # DNSSEC Validation Mock
                if not self.validate_dnssec(response_data):
                     logger.critical("DNSSEC Signature Invalid! Dropping spoofed response.")
                     # Drop packet to protect client
                     return
                self.transport.sendto(response_data, addr)
                
        except Exception as e:
            logger.error(f"Error handling query: {e}")

    def handle_threat(self, client_ip, qname, request, addr, reason, risk_increment):
        # 1. Increase Device Risk
        device = tracker.increase_risk(client_ip, risk_increment)
        
        # 2. Trigger SOAR if critical
        if device["score"] >= 80 and device.get("isolated") != True:
             soar_engine.isolate_device(client_ip, f"Risk score reached critical ({device['score']})")
             device["isolated"] = True # Prevent duplicate triggers
             
        # 3. Sinkhole
        reply = self.create_block_response(request)
        self.transport.sendto(reply.pack(), addr)

    def validate_dnssec(self, response_data: bytes) -> bool:
        """
        Simulates Cryptographic DNSSEC Validation.
        In a real scenario, this parses the RRSIG records and validates the chain of trust.
        """
        # Mock: 99% of requests pass, 1% are "spoofed" for demo purposes
        import random
        if random.random() > 0.99:
             return False
        return True

    async def check_threat_intel(self, domain: str) -> bool:
        # Mock TI check
        blocked_domains = {"malicious.com", "phishing.net"}
        return domain in blocked_domains

    async def check_ml_engine(self, domain: str) -> bool:
        # Check domain using ML features for DGA
        return dga_detector.predict(domain)

    async def forward_to_upstream(self, data: bytes) -> bytes:
        loop = asyncio.get_event_loop()
        
        class UpstreamProtocol(asyncio.DatagramProtocol):
            def __init__(self, future):
                self.future = future
                
            def datagram_received(self, response_data, addr):
                if not self.future.done():
                    self.future.set_result(response_data)
                    
            def error_received(self, exc):
                if not self.future.done():
                    self.future.set_exception(exc)
                    
            def connection_lost(self, exc):
                if not self.future.done() and exc is not None:
                     self.future.set_exception(exc)

        future = loop.create_future()
        transport, _ = await loop.create_datagram_endpoint(
            lambda: UpstreamProtocol(future),
            remote_addr=(UPSTREAM_DNS, 53)
        )
        transport.sendto(data)
        
        try:
            # Wait for response with timeout
            response_data = await asyncio.wait_for(future, timeout=2.0)
            return response_data
        except asyncio.TimeoutError:
            logger.error("Upstream DNS timeout")
            return None
        finally:
            transport.close()

    def create_block_response(self, request: DNSRecord) -> DNSRecord:
        # Return a sinkhole IP for blocked requests
        reply = request.reply()
        sinkhole_ip = "0.0.0.0"
        reply.add_answer(RR(request.q.qname, QTYPE.A, rdata=A(sinkhole_ip), ttl=60))
        return reply

async def start_dns_server():
    loop = asyncio.get_running_loop()
    transport, protocol = await loop.create_datagram_endpoint(
        lambda: DNSProxyProtocol(),
        local_addr=(DNS_HOST, DNS_PORT)
    )
    try:
        await asyncio.sleep(3600)  # Serve for 1 hour, or handle graceful shutdown
    finally:
        transport.close()

if __name__ == "__main__":
    asyncio.run(start_dns_server())
