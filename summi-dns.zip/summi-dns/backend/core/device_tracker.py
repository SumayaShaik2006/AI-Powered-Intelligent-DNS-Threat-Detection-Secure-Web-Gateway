import logging

logger = logging.getLogger("ZeroTrustTracker")

class DeviceTracker:
    def __init__(self):
        # Maps IP to a risk score (0-100)
        self.devices = {}
        
    def get_or_create_device(self, ip_address: str):
        if ip_address not in self.devices:
            self.devices[ip_address] = {
                "ip": ip_address,
                "score": 0,
                "status": "Safe"
            }
        return self.devices[ip_address]

    def increase_risk(self, ip_address: str, amount: int) -> dict:
        """Increases the risk score of a device based on malicious activity."""
        device = self.get_or_create_device(ip_address)
        
        device["score"] += amount
        if device["score"] > 100:
            device["score"] = 100
            
        # Update status tier
        if device["score"] >= 80:
            device["status"] = "Critical"
        elif device["score"] >= 40:
            device["status"] = "Warning"
            
        logger.warning(f"Device {ip_address} risk increased by {amount}. Current score: {device['score']} ({device['status']})")
        return device

# Singleton
tracker = DeviceTracker()
