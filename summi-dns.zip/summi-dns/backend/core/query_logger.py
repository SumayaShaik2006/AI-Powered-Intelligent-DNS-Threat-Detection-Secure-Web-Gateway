import logging
from datetime import datetime
from collections import Counter

logger = logging.getLogger("QueryLogger")

class QueryLogger:
    """
    Structured DNS query event logging system.
    Stores all query events in-memory (simulating a time-series database like InfluxDB).
    Provides real-time aggregate statistics for the dashboard.
    """
    def __init__(self):
        self._events = []

    def log_query(self, source_ip: str, domain: str, qtype: str, 
                  action: str, reason: str, response_time_ms: float = 0.0, 
                  is_cached: bool = False):
        """Log a single DNS query event."""
        event = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "source_ip": source_ip,
            "domain": domain,
            "qtype": qtype,
            "action": action,
            "reason": reason,
            "response_time_ms": round(response_time_ms, 2),
            "is_cached": is_cached
        }
        self._events.append(event)
        # Keep only the last 10000 events to prevent memory overflow
        if len(self._events) > 10000:
            self._events = self._events[-10000:]
        return event

    def get_recent(self, n: int = 50) -> list:
        """Return the most recent n query events."""
        return list(reversed(self._events[-n:]))

    def get_stats(self) -> dict:
        """Return aggregate statistics across all logged queries."""
        if not self._events:
            return {
                "total_queries": 0,
                "total_blocked": 0,
                "total_allowed": 0,
                "avg_response_time": 0,
                "cache_hit_rate": 0,
                "top_blocked_domains": []
            }

        total = len(self._events)
        blocked = [e for e in self._events if e["action"] == "BLOCKED"]
        allowed = [e for e in self._events if e["action"] == "ALLOWED"]
        cached = [e for e in self._events if e["is_cached"]]

        avg_rt = sum(e["response_time_ms"] for e in self._events) / total if total else 0

        blocked_domains = Counter(e["domain"] for e in blocked)
        top_blocked = [{"domain": d, "count": c} for d, c in blocked_domains.most_common(5)]

        return {
            "total_queries": total,
            "total_blocked": len(blocked),
            "total_allowed": len(allowed),
            "avg_response_time": round(avg_rt, 2),
            "cache_hit_rate": round(len(cached) / total * 100, 1) if total else 0,
            "top_blocked_domains": top_blocked
        }

# Singleton
query_logger = QueryLogger()
