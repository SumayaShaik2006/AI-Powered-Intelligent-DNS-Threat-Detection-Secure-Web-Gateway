import threading
import time
import logging

logger = logging.getLogger("DNSCache")

class DNSCache:
    """
    Intelligent in-memory DNS response cache with TTL-based expiry.
    Implements a local caching layer so repeated queries for the same
    domain are served instantly without upstream resolution.
    """
    def __init__(self):
        self._cache = {}  # {domain: {"response": bytes, "expires": float}}
        self._lock = threading.Lock()
        self._hits = 0
        self._misses = 0

    def get(self, domain: str):
        """Retrieve a cached DNS response if it exists and hasn't expired."""
        with self._lock:
            entry = self._cache.get(domain)
            if entry and entry["expires"] > time.time():
                self._hits += 1
                logger.debug(f"Cache HIT: {domain}")
                return entry["response"]
            elif entry:
                # Expired — evict it
                del self._cache[domain]
            self._misses += 1
            logger.debug(f"Cache MISS: {domain}")
            return None

    def put(self, domain: str, response: bytes, ttl: int = 300):
        """Store a DNS response with a TTL (seconds)."""
        with self._lock:
            self._cache[domain] = {
                "response": response,
                "expires": time.time() + ttl
            }
            logger.debug(f"Cached: {domain} (TTL={ttl}s)")

    def evict_expired(self):
        """Remove all expired entries from the cache."""
        now = time.time()
        with self._lock:
            expired_keys = [k for k, v in self._cache.items() if v["expires"] <= now]
            for key in expired_keys:
                del self._cache[key]
            if expired_keys:
                logger.info(f"Evicted {len(expired_keys)} expired cache entries.")

    def cache_stats(self) -> dict:
        """Return cache performance statistics."""
        total = self._hits + self._misses
        return {
            "total_entries": len(self._cache),
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": round((self._hits / total * 100), 1) if total > 0 else 0,
            "miss_rate": round((self._misses / total * 100), 1) if total > 0 else 0,
        }

# Singleton
dns_cache = DNSCache()
