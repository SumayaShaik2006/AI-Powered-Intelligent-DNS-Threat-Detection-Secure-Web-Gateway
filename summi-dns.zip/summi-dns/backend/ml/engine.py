import math
from collections import Counter
import logging

logger = logging.getLogger("MLEngine")

def shannon_entropy(domain: str) -> float:
    """Calculates the Shannon entropy of a domain name."""
    p, lns = Counter(domain), float(len(domain))
    return -sum(count/lns * math.log(count/lns, 2) for count in p.values())

class MLDetector:
    def __init__(self):
        # In a real scenario, we would load a trained model here
        # self.model = joblib.load('model.pkl')
        self.is_loaded = True
        logger.info("ML Model loaded.")

    def extract_features(self, domain: str) -> dict:
        """Extract features from the domain for ML prediction."""
        return {
            "length": len(domain),
            "entropy": shannon_entropy(domain),
            "vowel_ratio": sum(1 for c in domain if c in 'aeiou') / len(domain) if len(domain) > 0 else 0,
            "digit_ratio": sum(1 for c in domain if c.isdigit()) / len(domain) if len(domain) > 0 else 0
        }

    def detect_phishing(self, domain: str) -> bool:
        """
        NLP/Heuristic-based Phishing detection (e.g., typosquatting of popular brands).
        """
        targeted_brands = ['paypal', 'google', 'apple', 'microsoft', 'amazon', 'netflix']
        keywords = ['login', 'secure', 'update', 'verify', 'account']
        
        domain_lower = domain.lower()
        
        # Check for brand typosquatting or keyword stuffing
        for brand in targeted_brands:
            if brand in domain_lower and not domain_lower.endswith(f"{brand}.com"):
                for kw in keywords:
                    if kw in domain_lower:
                         logger.warning(f"Phishing detected via NLP heuristic: {domain}")
                         return True
        return False

    def predict(self, domain: str) -> bool:
        """
        Predicts if a domain is malicious using DGA or Phishing models.
        """
        # 1. NLP Phishing Check
        if self.detect_phishing(domain):
            return True

        # 2. DGA ML Check
        features = self.extract_features(domain)
        if features["entropy"] > 4.0 or (features["length"] > 15 and features["digit_ratio"] > 0.3):
             logger.warning(f"DGA detected for domain {domain} with features: {features}")
             return True
             
        return False

# Singleton instance
dga_detector = MLDetector()
